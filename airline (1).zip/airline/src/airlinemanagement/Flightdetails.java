
package airlinemanagement;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Flightdetails extends JFrame implements ActionListener{
    
     JFrame f;
     JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9;
     JTextField t1;
     JTable d;
     DefaultTableModel model;
     JButton b1;
     JComboBox<String> c1,c2;
     
      Flightdetails(){
      f= new JFrame ();
      f.setSize(1300,900);
      f.setResizable(false);
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)   ; 
      f.setLocationRelativeTo(null);
      f.setLayout(null);
      f.setFont( new Font("Arial Blue",Font.BOLD,30));
      f.setVisible(true);
           
      l1=new JLabel("FLIGHT INFORMATION");
      l1.setBounds(100,10,700,40);
      l1.setForeground(Color.blue);
      l1.setFont(new Font("arrial black",Font.BOLD,40));
      f.add(l1);
      
      l2=new JLabel("Source");
      l2.setBounds(50,100,200,40);
      l2.setForeground(Color.RED);
      l2.setFont(new Font("arrial black",Font.BOLD,30));
      f.add(l2);
      
      l3=new JLabel("Destination");
        l3.setBounds(520,100,300,40);
        l3.setForeground(Color.RED);
        l3.setFont(new Font("arrial black",Font.BOLD,30));
        f.add(l3);
     
        c1 = new JComboBox<>();
        c1.setBounds(200, 100, 250, 40);
        c1.setForeground(Color.BLACK);
        c1.setFont(new Font("Arrial Black",Font.BOLD,20));
        c1.addItem("LUCKNOW");
       c1.addItem("JAIPUR");
       c1.addItem("RAJISTHAN");
       c1.addItem("UTTRAKHAND");
       c1.addItem("JAMMU & KASMIR");
       c1.addItem("ODISHA");
       c1.addItem("MADHYA PRADESH");
       c1 .addItem("PUNJAB");
       c1.addItem("ANDRA PRADESH");
       c1.addItem("HIMACHAL PRADESH");
       c1.addItem("KERALA");
       c1.addItem("TAMIL NADU");
       c1.addItem("DELHI") ;
       f.add(c1);

     
        c2=new JComboBox<>();
        c2.setBounds(730, 100, 250, 40);
        c2.setForeground(Color.BLACK);
        c2.setFont(new Font("Arial Black",Font.BOLD,20));
        c2.addItem("BANGLORE");
        c2.addItem("CHATTISGHARH");
        c2.addItem("UTTRAKHAND");
        c2.addItem("KOLKATA");
        c2.addItem("HIMACHAL");
        c2.addItem("ANDRA PRADESH");
        c2.addItem("JAMMU & KASHMIR");
        c2.addItem("KERALA");
        c2.addItem("TAMIL NADU");
        c2.addItem("ODISHA");
        c2.addItem("MADHEY PRADESH");
        c2.addItem("MUMBAI");
        c2.addItem("LUCKNOW");
        f.add(c2);
        
        b1=new JButton("Search");
        b1.setBounds(1000,100,200,40);
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.setFont(new Font("Arrial Black",Font.BOLD,20));
        b1.addActionListener(this);
        
        f.add(b1);
        
        model = new DefaultTableModel();
        d = new JTable(model);
         model.setColumnIdentifiers(new String[]{"Flight_No", "Flight_Name", "Source", "Destination", "flight_Date","Departure_Time", "Arrival_Time","Charges"});
        d.setFont(new Font("Arrial Black",Font.BOLD,20));
        JScrollPane scrollPane = new JScrollPane(d);
        scrollPane.setBounds(50, 200, 1200, 600);
        f.add(scrollPane);

        

     }

    Flightdetails(String flightId, String flightName, String arrivalTime) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
      public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            searchFlights();
        }
      }
      private void searchFlights() {
        String source = (String) c1.getSelectedItem();
        String destination = (String) c2.getSelectedItem();

        String jdbcURL = "jdbc:mysql://localhost:3306/airlinemanagement";
        String username = "root";
        String password = "Vivo123@";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/airlinemanagement", "root","Vivo123@" );

            String query = "SELECT * FROM flight WHERE source=? AND destination=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, source);
            preparedStatement.setString(2, destination);

            ResultSet resultSet = preparedStatement.executeQuery();
              model.setRowCount(0);


        // Populate the table with data from the result set
        while (resultSet.next()) {
            Object[] row = {
                resultSet.getString("flight_no"),
                resultSet.getString("flight_name"),
                resultSet.getString("source"),
                resultSet.getString("destination"),
                resultSet.getString("flight_date"),
                resultSet.getString("departure_time"),
                resultSet.getString("arrival_time"),
                resultSet.getString("charges")
            };
            model.addRow(row);
        }

        preparedStatement.close();
        connection.close();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
}
        
          


      public static void main(String []a){
        Flightdetails t= new Flightdetails();
    
    }

   

    
    }
   
    
    
    


           
       

    