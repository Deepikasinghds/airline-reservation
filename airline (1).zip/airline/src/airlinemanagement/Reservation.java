package airlinemanagement;
import java.awt.*;
import java.awt.event.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class Reservation extends JFrame implements ActionListener{

    JFrame f;
    JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,t,u,m,k,o,p,x,r,b;
    JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
    JButton b1,b2,b3,b4,b5,b6,b7;
     JTable d;
     DefaultTableModel model;
    JComboBox<String> c1,c2,c3,c4;
    int ticketCounter = 301;  
    Connection connection;
    Statement statement;
    ResultSet resultSet;
    JSpinner s;

    Panel p1,p2;    
    
    Reservation(){
        f=new JFrame("Book Ticket");
        b=new JLabel("",new ImageIcon("yt.jpg"),JLabel.CENTER);
        b.setBounds(0,0,1800,950);
        f.add(b);
      
        f.setSize(1800,950);
        f.setResizable(false);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)   ; 
        f.setLocationRelativeTo(null);
        f.setLayout(null);
        f.setFont( new Font("Arial Blue",Font.BOLD,30));
        f.setVisible(true);
        
        
        p1=new Panel();
        p1.setBounds(10, 10, 750, 380);
        p1.setLayout(null);
        p1.setBackground(Color.WHITE);
        b.add(p1);
        
        
       l1=new JLabel("SOURCE");
       l1.setBounds(50,50,300,40);
       l1.setFont(new Font("arrial Black",Font.BOLD,30));
       p1.add(l1);
       
       l2=new JLabel("DESTINATION");
       l2.setBounds(350,50,300,40);
       l2.setFont(new Font("arrial Black",Font.BOLD,30));
       p1.add(l2);
        
       c1 = new JComboBox<>();
        c1.setBounds(50, 100, 250, 40);
        c1.setForeground(Color.BLACK);
        c1.setFont(new Font("Arrial Black",Font.BOLD,20));
       c1.addItem("LUCKNOW");
       c1.addItem("JAIPUR");
       c1.addItem("RAJISTHAN");
       c1.addItem("UTTRAKHAND");
       c1.addItem("JAMMU & KASMIR");
       c1.addItem("ODISHA");
       c1.addItem("MADHYA PRADESH");
       c1 .addItem("PUNJAB");
       c1.addItem("ANDRA PRADESH");
       c1.addItem("HIMACHAL PRADESH");
       c1.addItem("KERALA");
       c1.addItem("TAMIL NADU");
       c1.addItem("DELHI") ;
       p1.add(c1);
       
        c2=new JComboBox<>();
        c2.setBounds(380, 100, 250, 40);
        c2.setForeground(Color.BLACK);
        c2.setFont(new Font("Arial Black",Font.BOLD,20));
        c2.addItem("BANGLORE");
        c2.addItem("CHATTISGHARH");
        c2.addItem("UTTRAKHAND");
        c2.addItem("KOLKATA");
        c2.addItem("HIMACHAL");
        c2.addItem("ANDRA PRADESH");
        c2.addItem("JAMMU & KASHMIR");
        c2.addItem("KERALA");
        c2.addItem("TAMIL NADU");
        c2.addItem("ODISHA");
        c2.addItem("MADHEY PRADESH");
        c2.addItem("MUMBAI");
        c2.addItem("LUCKNOW");
        p1.add(c2);
       
      
        b1=new JButton("SEARCH");
        b1.setBounds(240,280,200,40);
        b1.addActionListener(this);
        p1.add(b1);
        
        model = new DefaultTableModel();
        d = new JTable(model);
         model.setColumnIdentifiers(new String[]{"Flight_No", "Flight_Name", "Source", "Destination", "flight_Date","Departure_Time", "Arrival_Time","Charges"});
        d.setFont(new Font("Arrial Black",Font.BOLD,20));
        JScrollPane scrollPane = new JScrollPane(d);
        scrollPane.setBounds(5, 500, 900, 350);
        b.add(scrollPane);
        
        l3=new JLabel("TICKET NO");
        l3.setBounds(850,50,200,40);
        l3.setFont(new Font("Arrial Black",Font.BOLD,30));
        l3.setForeground(Color.red);
        f.add(l3);

        t=new JLabel("n");
        t.setBounds(850,100,200,40);
        t.setFont(new Font("Arrial Black",Font.BOLD,30));
        b.add(t);
        
       l4=new JLabel("FLIGHT ID");
       l4.setBounds(1000,400,200,40);
       l4.setFont(new Font("Arrial Black",Font.BOLD,20));
       b.add(l4);
       
       u=new JLabel("i");
       u.setBounds(1200,400,200,40);
       u.setFont(new Font("Arrial Black",Font.BOLD,20));
       u.setForeground(Color.red);
       b.add(u);
       
       l5=new JLabel("FLIGHT NAME");
       l5.setBounds(1000,450,200,40);
       l5.setFont(new Font("Arial Black",Font.BOLD,20));
       b.add(l5);
       
       o=new JLabel("NA");
       o.setBounds(1200,450,200,40);
       o.setFont(new Font("Arrial Black",Font.BOLD,20));
       o.setForeground(Color.red);
       b.add(o);
       
       l6=new JLabel("DEPART TIME");
       l6.setBounds(1000,500,200,40);
       l6.setFont(new Font("Arial Black",Font.BOLD,20));
       b.add(l6);
       
       
       k=new JLabel("de");
       k.setBounds(1200,500,200,40);
       k.setFont(new Font("Arrial Black",Font.BOLD,20));
       k.setForeground(Color.red);
       b.add(k);
       
       l7=new JLabel("CLASS");
       l7.setBounds(1000,550,200,40);
       l7.setFont(new Font("Arial BLACK",Font.BOLD,20));
       b.add(l7);
       
        c3= new JComboBox<>();
        c3.setBounds(1200,550,200,40);
        c3.setFont(new Font("Arial BLACK",Font.BOLD,20));
        c3.addItem("Economic" );
        c3.addItem("Bussiness");
        c3.addItem("First");
        b.add(c3);
        
        l8=new JLabel("PRICE");
        l8.setBounds(1000,600,200,40);
        l8.setFont(new Font("Arial Black",Font.BOLD,20));
        b.add(l8);
        
        
        
        b2=new JButton("Search");
        b2.setBounds(1400,200,200,40);
        b2.addActionListener(this);
        b.add(b2);
        
        
        l9=new JLabel("USER ID");
        l9.setBounds(1000,200,200,40);
        l9.setFont(new Font("Arial Black",Font.BOLD,20));
        b.add(l9);
        
        t1=new JTextField("");
        t1.setBounds(1200,200,200,40);
        t1.setFont(new Font("Arial Black",Font.BOLD,20));
        b.add(t1);
        
         l10=new JLabel("FIRST NAME");
         l10.setBounds(1000,250,200,40);
         l10.setFont(new Font("Arial Black",Font.BOLD,20));
         b.add(l10);
         
         p=new JLabel("k");
         p.setBounds(1200,250,200,40);
         p.setForeground(Color.red);
         p.setFont(new Font("Arial Black",Font.BOLD,20));
         b.add(p);
         
         l11=new JLabel("LAST NAME");
         l11.setBounds(1000,300,200,40);
         l11.setFont(new Font("Arial Black",Font.BOLD,20));
         b.add(l11);
         
        m=new JLabel("j");
        m.setBounds(1200,300,200,40);
        m.setForeground(Color.red);
        m.setFont(new Font("Arial Black",Font.BOLD,20));
        b.add(m);
        
        b3=new JButton("Book");
        b3.setBounds(1100,740,200,40);
        b3.addActionListener(this);
        b.add(b3);
        
        b4=new JButton("Cancel");
        b4.setBounds(1350,740,200,40);
        b4.addActionListener(this);
        b.add(b4);
        
        l12=new JLabel("SEATS");
        l12.setBounds(1000,650,200,40);
        l12.setFont(new Font("Arial Black",Font.BOLD,20));
        b.add(l12);
        
         r=new JLabel("");
         r.setBounds(1200,600,200,40);
         r.setFont(new Font("Arial Black",Font.BOLD,20));
         r.setForeground(Color.red);
         b.add(r);
        
        x=new JLabel("TOTAL PRICE");
        x.setBounds(1450,500,200,40);
        x.setFont(new Font("Arial Black",Font.BOLD,30));
        x.setForeground(Color.red);
        b.add(x);
        
        l13=new JLabel("BOOK TICKET");
        l13.setBounds(1150,20,400,40);
        l13.setFont(new Font("Arial Black",Font.BOLD,40));
        l13.setForeground(Color.red);
        b.add(l13);
        
        s = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1)); 
        s.setBounds(1200, 650, 200, 40);
        s.setFont(new Font("Arial Black",Font.BOLD,20));
        b.add(s);
        
        generateTicketNumber();
        
        d.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent event) {
                if (!event.getValueIsAdjusting() && d.getSelectedRow() != -1) {
                    int selectedRow = d.getSelectedRow();
                  
                    String flightId = d.getValueAt(selectedRow, 0).toString();
                    String flightName = d.getValueAt(selectedRow, 1).toString();
                    String departTime = d.getValueAt(selectedRow, 5).toString();
                    String charges = d.getValueAt(selectedRow, 7).toString();

                 
                    u.setText(flightId);
                    o.setText(flightName);
                    k.setText(departTime);
                    r.setText(charges);
                    updatePrice();
                }
            }

            private void updatePrice() {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            
        });
        s.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                
                updatePrice();
                //To change body of generated methods, choose Tools | Templates.
            }
            // Update price when spinner value changes

            //To change body of generated methods, choose Tools | Templates.
            
            
        });
    
    }
    
     public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            searchFlights();
        }
        else if(e.getSource()==b2){
           String userId = t1.getText();
            try { 
                searchUserDetails(userId);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Reservation.class.getName()).log(Level.SEVERE, null, ex);
            }
     
        }
       else if(e.getSource()==b3) {
           JOptionPane.showMessageDialog(f, "Now procced to payement");
            
   
    String ticketNumber = t.getText();
    
    
    new book(ticketNumber);
}

        else if(e.getSource()==b4){
            f.dispose();
            new homepage();
        }
      }
      
      private void searchFlights() {
        String source = (String) c1.getSelectedItem();
        String destination = (String) c2.getSelectedItem();

        String jdbcURL = "jdbc:mysql://localhost:3306/airlinemanagement";
        String username = "root";
        String password = "Vivo123@";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/airlinemanagement", "root", "Vivo123@");

            String query = "SELECT * FROM flight WHERE source=? AND destination=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, source);
            preparedStatement.setString(2, destination);

            ResultSet resultSet = preparedStatement.executeQuery();
            model.setRowCount(0);

            
            while (resultSet.next()) {
                Object[] row = {
                        resultSet.getString("flight_no"),
                        resultSet.getString("flight_name"),
                        resultSet.getString("source"),
                        resultSet.getString("destination"),
                        resultSet.getString("flight_date"),
                        resultSet.getString("departure_time"),
                        resultSet.getString("arrival_time"),
                        resultSet.getString("charges")
                };
                model.addRow(row);
            }

            preparedStatement.close();
            connection.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
      
      
      private void searchUserDetails(String userId) throws ClassNotFoundException {
        String query = "SELECT * FROM user1 WHERE user_id = '" + userId + "'";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/airlinemanagement", "root", "Vivo123@");
        statement = connection.createStatement();
            resultSet = statement.executeQuery(query);

            if (resultSet.next()) {
                p.setText(resultSet.getString("first_name"));
                m.setText(resultSet.getString("last_name"));
                
            } else {
                JOptionPane.showMessageDialog(f, "User not found", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
   /* private void bookTicket() {
    
    JOptionPane.showMessageDialog(f, "Booking Successfull ", JOptionPane.INFORMATION_MESSAGE);
      JOptionPane.showMessageDialog(f, "Now Procced to Payement", JOptionPane.INFORMATION_MESSAGE);
}*/

private void updatePrice() {
    String chargesStr = r.getText();
    if (!chargesStr.isEmpty()) {
        double charges = Double.parseDouble(chargesStr);
        int seats = (int) s.getValue();
        double totalPrice = charges * seats;
        x.setText("" + totalPrice);
    } else {
        x.setText("TOTAL PRICE: N/A");
    }
}

    
      private void generateTicketNumber() {
        t.setText(String.valueOf(ticketCounter++));
    }
      
    public static void main(String []args){
        Reservation h= new Reservation();
    }

    private void search() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void searchUserDetails() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
    