
package airlinemanagement;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class addpassengerdeatil  extends JFrame implements ActionListener{
    JFrame f,f1;
    JButton b1,b2,b3,b4;
    JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,Background,k,m;
    JPanel p1,p2;
    JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
    JComboBox<String> c1,c2;
   
    
      
    addpassengerdeatil()
         
    {
     f=new JFrame();
     Background=new JLabel("",new ImageIcon("air.jpg"),JLabel.CENTER);
        Background.setBounds(0,0,1100,900);
        f.add(Background);
      
        f.setSize(1100,900);
        f.setResizable(false);
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)   ; 
      f.setLocationRelativeTo(null);
      f.setLayout(null);
     
       f.setFont( new Font("Arial Blue",Font.BOLD,30));
      
      
      
      p1 = new JPanel();
      p1.setBounds(10, 50, 480, 700);
      p1.setLayout(null);
      p1.setBackground(Color.WHITE);
      Background.add(p1);
      
      p2 = new JPanel();
      p2.setBounds(600, 270, 300, 300);
      p2.setLayout(null);
      p2.setBackground(Color.lightGray);
      Background.add(p2);
      
      
      
      l1=new JLabel("Regestration deatils");
      l1.setBounds(5,5,300,30);
      l1.setFont( new Font("Arial Blue",Font.BOLD,30));
      
      Background.add(l1);
        
      l2=new JLabel("User_ID");
      l2.setBounds(20,20,200,30);
      l2.setFont(new Font("SERIF Black",Font.BOLD,20));
      p1.add(l2);
      t2 = new JTextField();
        t2.setBounds(250, 20, 200, 30);
        t2.setFont(new Font("SERIF Black",Font.BOLD,20));
        p1.add(t2);
      
       l3=new JLabel("First Name");
      l3.setBounds(20,100,200,30);
      l3.setFont(new Font("SERIF Black",Font.BOLD,20));
      p1.add(l3);
      k = new JLabel("");
        k.setBounds(250, 100, 200, 30);
        k.setFont(new Font("SERIF Black",Font.BOLD,20));
        k.setForeground(Color.red);
        p1.add(k);
        
      
       l4=new JLabel("Last Name");
      l4.setBounds(20,170,200,30);
      l4.setFont(new Font("SERIF Black",Font.BOLD,20));
      p1.add(l4);
      
      m= new JLabel("");
        m.setBounds(250, 170, 200, 30);
        m.setFont(new Font("SERIF Black",Font.BOLD,20));
        m.setForeground(Color.red);
        p1.add(m);
      
       l5=new JLabel("Address");
      l5.setBounds(20,230,200,30);
      l5.setFont(new Font("SERIF Black",Font.BOLD,20));
      p1.add(l5);
      
        t5 = new JTextField();
        t5.setBounds(250, 230, 200, 30);
        t5.setFont(new Font("SERIF Black",Font.BOLD,20));
        p1.add(t5);
      
      l6=new JLabel("Contact No");
      l6.setBounds(20,290,200,30);
      l6.setFont(new Font("SERIF Black",Font.BOLD,20));
      p1.add(l6);
      
        t6 = new JTextField();
        t6.setBounds(250, 290, 200, 30);
        t6.setFont(new Font("SERIF Black",Font.BOLD,20));
        p1.add(t6);
        
      
       l7=new JLabel("Email_Id");
       l7.setBounds(20,350,200,30);
       l7.setFont(new Font("SERIF Black",Font.BOLD,20));
       p1.add(l7);
       
        t7 = new JTextField();
        t7.setBounds(250, 350, 200, 30);
        t7.setFont(new Font("SERIF Black",Font.BOLD,20));
        p1.add(t7);
        
      
      l8=new JLabel("Passport_no");
      l8.setBounds(20,410,200,30);
      l8.setFont(new Font("SERIF Black",Font.BOLD,20));
      p1.add(l8);
        
        t8 = new JTextField();
        t8.setBounds(250, 410, 200, 30);
        t8.setFont(new Font("SERIF Black",Font.BOLD,20));
        p1.add(t8);
      
      l9=new JLabel("Gender");
      l9.setBounds(20,480,200,30);
      l9.setFont(new Font("SERIF Black",Font.BOLD,20));
      p1.add(l9);
      
        String[] genders = {"Male", "Female", "Other"};
        c1= new JComboBox<>(genders);
        c1.setBounds(250, 480, 200, 30);
        c1.setFont(new Font("SERIF Black",Font.BOLD,20));
        p1.add(c1);
      
     
       l10=new JLabel("City"); 
       l10.setBounds(20,530,200,30);
       l10.setFont(new Font("SERIF Black",Font.BOLD,20));
      p1.add(l10);
      
        String[] cities = {"Delhi", "Ghaziabad", "Meerut","Modinagar","Agra","Lucknow"}; 
        c2 = new JComboBox<>(cities);
        c2.setBounds(250, 530, 200, 30);
        c2.setFont(new Font("SERIF Black",Font.BOLD,20));
        p1.add(c2);
        
        b1 = new JButton("Save");
        b1.setBounds(20, 50, 240, 30);
        b1.setFont(new Font("SERIF Black",Font.BOLD,20));
        b1.addActionListener(this);
        p2.add(b1);
        
        b2 = new JButton("New");
        b2.setBounds(20, 100, 240, 30);
        b2.setFont(new Font("SERIF Black",Font.BOLD,20));
        b2.addActionListener(this);
        p2.add(b2);
        
        b3 = new JButton("Delete");
        b3.setBounds(20, 150, 240, 30);
        b3.setFont(new Font("SERIF Black",Font.BOLD,20));
        b3.addActionListener(this);
        p2.add(b3);
        
        b4 = new JButton("GetData");
        b4.setBounds(20, 200, 240, 30);
        b4.setFont(new Font("SERIF Black",Font.BOLD,20));
        b4.addActionListener(this);
        p2.add(b4);
        
       
      
        f.setVisible(true);
        }
        public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            savePassengerDetails();
            homepage m= new homepage();
        } else if (e.getSource() == b2) {
            clearFields();
        } else if (e.getSource() == b3) {
            deletePassengerDetails();
        } else if (e.getSource() == b4) {
            getPassengerData();
        }
    }

   private void savePassengerDetails() {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airlinemanagement", "root",
                    "Vivo123@");
            PreparedStatement pst = con.prepareStatement(
                    "INSERT INTO passenger1(user_id, first_name, last_name, address, contact_no, email_id, passport_no, gender, city) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

            pst.setString(1, t2.getText());
            pst.setString(2, k.getText());
            pst.setString(3, m.getText());
            pst.setString(4, t5.getText());
            pst.setString(5, t6.getText());
            pst.setString(6, t7.getText());
            pst.setString(7, t8.getText());
            pst.setString(8, c1.getSelectedItem().toString());
            pst.setString(9, c2.getSelectedItem().toString());

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(f, "Passenger details saved successfully!");
                clearFields();
            } else {
                JOptionPane.showMessageDialog(f, "Failed to save passenger details.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(f, "Error saving passenger details.\n" + ex.getMessage());
        }
   }

   private void deletePassengerDetails() {
    try {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airlinemanagement", "root", "Vivo123@");
        PreparedStatement pst = con.prepareStatement("UPDATE passenger1 SET address = NULL, contact_no = NULL, passport_no = NULL, email_id = NULL, gender = NULL, city = NULL WHERE user_id = ?");
        pst.setString(1, t2.getText());

        int rowsAffected = pst.executeUpdate();
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(f, "Selected details for the passenger deleted successfully!");
            clearFields();
        } else {
            JOptionPane.showMessageDialog(f, "No record found for the provided User_ID.");
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(f, "Error deleting passenger details.\n" + ex.getMessage());
    }
}

   private void getPassengerData() {
    try {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airlinemanagement", "root", "Vivo123@");
        PreparedStatement pst = con.prepareStatement("SELECT first_name, last_name FROM user1 WHERE user_id = ?");
        pst.setString(1, t2.getText());

        ResultSet resultSet = pst.executeQuery();
        if (resultSet.next()) {
            k.setText(resultSet.getString("first_name"));
            m.setText(resultSet.getString("last_name"));
        } else {
            JOptionPane.showMessageDialog(f, "No record found for the provided User_ID.");
            // Clear the fields if no record is found
            clearFields();
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(f, "Error retrieving user details.\n" + ex.getMessage());
    }
}
   private void clearFields() {
    t2.setText("");
    t3.setText("");
    t4.setText("");
    t5.setText("");
    t6.setText("");
    t7.setText("");
    t8.setText("");
    k.setText(""); // Clear the labels as well
    m.setText("");
    c1.setSelectedIndex(0);
    c2.setSelectedIndex(0);
}

 public static void main(String args[]){
        addpassengerdeatil h =new addpassengerdeatil();
    }

   
}
       