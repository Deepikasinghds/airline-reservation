/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airlinemanagement;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;




public class adminsection extends JFrame implements ActionListener {
    JFrame f;
    JLabel l1,l2,l3,Background;
    Button b1,b2,b3,b4;
  
     adminsection()
    {
        f=new JFrame("admin section");
       Background=new JLabel("",new ImageIcon("th.jpg"),JLabel.CENTER);
        Background.setBounds(300,100,260,180);
        f.add(Background);
      
      
      f.setSize(600,400);
      f.setResizable(false);
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)   ; 
      f.setLocationRelativeTo(null);
      f.setLayout(null);
     
      f.setFont( new Font("Arial Black",Font.BOLD,30));
      f.setVisible(true);
      
      l1=new JLabel("Admin Section");
      l1.setBounds(50,0,350,100);
      l1.setForeground(Color.BLACK);
      l1.setFont(new Font("Arial Black",Font.BOLD,30));
     f.add(l1);
      
     
     
     b1=new Button("Add Flights");
      b1.setBounds(5,100,250,40);
      b1.setBackground(Color.BLACK);
      b1.setForeground(Color.WHITE);
            b1.setFont(new Font("Arial Black",Font.BOLD,20));
            b1.addActionListener(this);
            f.add(b1);
            
      
    b2=new Button("Update Flights");
      b2.setBounds(5,160,250,40);
      b2.setBackground(Color.BLACK);
      b2.setForeground(Color.WHITE);
            b2.setFont(new Font("Arial Black",Font.BOLD,20));
             b2.addActionListener(this);
            f.add(b2);
            

            b3=new Button("Add Airline Employee");
      b3.setBounds(5,220,250,40);
      b3.setBackground(Color.BLACK);
      b3.setForeground(Color.WHITE);
            b3.setFont(new Font("Arial Black",Font.BOLD,20));
            b3.addActionListener(this);
            f.add(b3);
            
      
    
                 b4=new Button("Add Airline Employee");
      b4.setBounds(5,280,250,40);
      b4.setBackground(Color.BLACK);
      b4.setForeground(Color.WHITE);
            b4.setFont(new Font("Arial Black",Font.BOLD,20));
            f.add(b4);
      
    
}
     
           public void actionPerformed(ActionEvent e) {
                
                
                
                
                if(e.getSource()==b1)
                {
                    
                        new Flightdetails();
                    }
                     else if(e.getSource()==b2)
                      {
                     new updatedetails();
                      }
                
                     else if(e.getSource()==b3)
                     {
                        new homepage(); 
                    }
                    
                                    }
            
     
     



     
     
     
   
public static void main(String [] s )
      {
          adminsection l=new adminsection();
                  }
}
