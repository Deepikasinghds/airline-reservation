
package airlinemanagement;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax .swing.*;


class book extends JFrame implements ActionListener {
    JFrame f;
    JLabel l1,l2,l3,l4,l5,l6,l7,b;
    JTextField t1,t2,t3,t4,t5;
    JComboBox<String> c1,c2;
    JButton b1,b2;
    String ticketID;
    
    
        book(String ticketID){
        this.ticketID = ticketID; 
    
        f=new JFrame("Payement");
        
        f.setSize(800,650);
        f.setResizable(false);
        Color u= new Color(240,220,200);
        f.setLocationRelativeTo(null);
        f.setLayout(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
        
        
        l1=new JLabel("PAYEMENT");
        l1.setBounds(220,10,300,40);
        l1.setFont(new Font("Arial Black",Font.BOLD,40));
        l1.setForeground(Color.BLUE);
        f.add(l1);
        
        l2=new JLabel("TICKET NO");
        l2.setBounds(50,150,300,40);
        l2.setFont(new Font("Arial Black",Font.BOLD,20));
        f.add(l2);
        
        l3=new JLabel("CARD NUMBER");
        l3.setBounds(50,200,300,40);
        l3.setFont(new Font("Arial Black",Font.BOLD,20));
        f.add(l3);
        
        l4=new JLabel("CARD TYPE");
        l4.setBounds(50,250,300,40);
        l4.setFont(new Font("Arial Black",Font.BOLD,20));
        f.add(l4);
        
        l5=new JLabel("CARD HOLDER NAME");
        l5.setBounds(50,300,300,40);
        l5.setFont(new Font("Arial Black",Font.BOLD,20));
        f.add(l5);
        
        l6=new JLabel("EXPIRY DATE");
        l6.setBounds(50,350,300,40);
        l6.setFont(new Font("Arial Black",Font.BOLD,20));
        f.add(l6);
        
        l7=new JLabel("CVV NUMBER");
        l7.setBounds(50,400,300,40);
        l7.setFont(new Font("Arial Black",Font.BOLD,20));
        f.add(l7);
       
        t1=new JTextField(ticketID);
        t1.setBounds(450,150,200,40);
        t1.setFont(new Font("Arial Black",Font.BOLD,20));
        t1.setEditable(false);
        f.add(t1);
        
        t2=new JTextField("");
        t2.setBounds(450,200,200,40);
        t2.setFont(new Font("Arial Black",Font.BOLD,20));
        f.add(t2);
        
        c1=new JComboBox<String>();
        c1.setBounds(450,250,200,40);
        c1.setFont(new Font("Arial Black",Font.BOLD,20));
        c1.addItem("VISA");
        c1.addItem("RUPAY");
        c1.addItem("MASTER CARD");
        f.add(c1);
        
       t3=new JTextField("");
       t3.setBounds(450,300,200,40);
       t3.setFont(new Font("Arial Black",Font.BOLD,20));
       f.add(t3);
       
       t4=new JTextField("");
       t4.setBounds(450,350,200,40);
       t4.setFont(new Font("Arial Black",Font.BOLD,20));
       f.add(t4);
       
       t5=new JTextField("");
       t5.setBounds(450,400,200,40);
       t5.setFont(new Font("Arial Black",Font.BOLD,20));
       f.add(t5);
       
       
       b1=new JButton("Done");
       b1.setBounds(450,480,200,40);
       b1.addActionListener(this);
       f.add(b1);
       
       b2=new JButton("ABORT");
       b2.setBounds(200,480,200,40);
       b2.addActionListener(this);
       f.add(b2);
        
    }

     
    
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==b1){
            JOptionPane.showMessageDialog(f, "Your Flight Booked Succesfully");
             JOptionPane.showMessageDialog(f, "NOTE ticket Number");
             String cardNumber = t2.getText();
        String cardType = (String) c1.getSelectedItem();
        String cardHolderName = t3.getText();
        String expiryDate = t4.getText();
        String cvvNumber = t5.getText();

      
        String jdbcURL = "jdbc:mysql://localhost:3306/airlinemanagement";
        String username = "root";
        String password = "Vivo123@";

        try {
            
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/airlinemanagement", "root", "Vivo123@");

             Class.forName("com.mysql.cj.jdbc.Driver");
            String sql = "INSERT INTO payement (ticket_id, card_number, card_type, card_holder_name, expiry_date, cvv_number) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, ticketID);
            statement.setString(2, cardNumber);
            statement.setString(3, cardType);
            statement.setString(4, cardHolderName);
            statement.setString(5, expiryDate);
            statement.setString(6, cvvNumber);

           
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(f, "Payment details stored successfully.");
                JOptionPane.showMessageDialog(f, "Your Flight Booking Successful. Note your ticket number: " + ticketID);
                new homepage();
            } else {
                JOptionPane.showMessageDialog(f, "Failed to store payment details.");
            }

            
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(f, "Error: " + ex.getMessage());
        }   catch (ClassNotFoundException ex) {
                Logger.getLogger(book.class.getName()).log(Level.SEVERE, null, ex);
            }
            new homepage();
        }
        else if(e.getSource()==b2){
             JOptionPane.showMessageDialog(f, "Your Payement cancel");
            new homepage();
        }
    
    }
  public static void main(String []args){
      book h= new book("");
  }  
}
