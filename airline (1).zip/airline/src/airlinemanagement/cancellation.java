
package airlinemanagement;
import java.lang.NullPointerException.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;



public class cancellation implements ActionListener {
    JFrame f;
    Button b1,b2;
    JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,Background1;
    TextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
    Checkbox c1,c2;
    
    
      
    cancellation()
    {
        
           f=new JFrame("CANCELLATION");
   Background1=new JLabel("",new ImageIcon("i.jpeg"),JLabel.CENTER);
        Background1.setBounds(550,250,400,350);
        f.add(Background1);
        f.setSize(900,800);
     
        
        
        
        
        
        f.setResizable(false);
        Color u= new Color(240,220,200);
        
        f.setLocationRelativeTo(null);
        f.setLayout(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        f.setVisible(true);
        
        
        l1=new JLabel("CANCELLATION");
        l1.setBounds(170,50,500,80);
        l1.setFont( new Font("Arial Black",Font.BOLD,40));
        f.add(l1);
        
                l2=new JLabel("PASSENGER NO");
                l2.setBounds(50,200,250,30);
                        l2.setFont( new Font("Arial Black",Font.BOLD,20));

                f.add(l2);
                
              
                l3=new JLabel("CANCELLATION NO");
                l3.setBounds(50,280,250,30);
                        l3.setFont( new Font("Arial Black",Font.BOLD,20));

                f.add(l3);
                
                l4=new JLabel("CANCELLATION DATE");
                l4.setBounds(50,360,250,30);
                        l4.setFont( new Font("Arial Black",Font.BOLD,20));

                f.add(l4);
                l5=new JLabel("TICKET_ID");
                l5.setBounds(50,440,250,30);
                        l5.setFont( new Font("Arial Black",Font.BOLD,20));

                f.add(l5);
                l5=new JLabel("FLIGHT_CODE");
                l5.setBounds(50,520,250,30);
                        l5.setFont( new Font("Arial Black",Font.BOLD,20));

                f.add(l5);
                t2=new TextField("");
                t2.setBounds(220,200,300,30);
                 f.add(t2);
                
                
                t3=new TextField("");
                t3.setBounds(220,280,300,30);
                 f.add(t3);
                
                
                
                
                t4=new TextField("");
                t4.setBounds(220,360,300,30);
                 f.add(t4);
                
                t5=new TextField("");
                t5.setBounds(220,440,300,30);
                 f.add(t5);
                
                
                t6=new TextField("");
                t6.setBounds(220,520,300,30);
                f.add(t6);
                
                
                
        
      
       
       
      b1=new Button("cancel");
      b1.setBounds(300,650,180,40);
      b1.setBackground(Color.BLUE);
       b1.setFont( new Font("Arial Black",Font.BOLD,20));

      f.add(b1);
      b1.addActionListener(this); 
                
      
    }  
    
     public void actionPerformed(ActionEvent e) {
    String passengerNo = t2.getText();
    String cancellationNo = t3.getText();
    String cancellationDate = t4.getText();
    String ticketId = t5.getText();
    String flightCode = t6.getText();

    JOptionPane.showMessageDialog(f, "Cancellation initiated for Passenger No: " + passengerNo);
}
    

    public static void main(String[] a) {
        cancellation g = new cancellation();
    
  

    

    }
}