package airlinemanagement;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class homepage  extends JFrame implements ActionListener {
    JFrame f;
    JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,Background;
    MenuBar m;
    Menu m1,m2,m3,m4,m5,m6;
    MenuItem i1,i2,i3,i4,i5,i6;
    homepage(){
        f=new JFrame();
        Background=new JLabel("",new ImageIcon("s.jpg"),JLabel.CENTER);
        Background.setBounds(0,0,1200,900);
        f.add(Background);
        f.setSize(1200,900);
        f.setResizable(false);
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)   ; 
      f.setLocationRelativeTo(null);
      f.setLayout(null);
     
      f.setFont( new Font("Arial Blue",Font.BOLD,30));
        f.setVisible(true);
        
        m= new MenuBar();
        m.setFont(new Font("arrial black",Font.BOLD,40));
        f.setMenuBar(m);
        
        m1=new Menu("Home");
        m1.setFont(new Font("arrial black",Font.BOLD,20));
        m.add(m1);
        
        m2=new Menu("Customer");
        m2.setFont(new Font("arrial black",Font.BOLD,20));
        m.add(m2);
        i1= new MenuItem("Add customer");
        i1.setFont(new Font("arrial black",Font.BOLD,20));
        i1.addActionListener(this);
        m2.add(i1);
        
        i2=new MenuItem("Search Customer");
        i2.setFont(new Font("arrial black",Font.BOLD,20));
        m2.add(i2);
        
        m3=new Menu("Flights");
        m3.setFont(new Font("arrial black",Font.BOLD,20));
        m.add(m3);
        i3=new MenuItem("Search Flight");
        i3.setFont(new Font("arrial black",Font.BOLD,20));
        i3.addActionListener(this);
        m3.add(i3);
        
        m4=new Menu("Ticket");
        m4.setFont(new Font("arrial black",Font.BOLD,20));
        m.add(m4);
        i4=new MenuItem("Ticket reserve");
        i4.setFont(new Font("arrial black",Font. BOLD,20));
        i4.addActionListener(this);
        m4.add(i4);
        
        
        l1=new JLabel("WHERE");
        l1.setBounds(140,100,300,70);
        l1.setFont(new Font("Serif black",Font.BOLD,60));
        Background.add(l1);
        
        l2=new JLabel("DO YOU WANT TO");
        l2.setBounds(140,150,500,70);
        l2.setFont(new Font("Serif black",Font.BOLD,60));
        Background.add(l2);
        
        l3=new JLabel("EXPLORE !");
        l3.setBounds(140,200,500,100);
        l3.setForeground(Color.BLUE);
        l3.setFont(new Font("Serif black",Font.BOLD,80));
        Background.add(l3);
}
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource()==i1){
            new addpassengerdeatil();
        }
        else if(e.getSource()== i2){
            
        }
        else if(e.getSource()== i3){
            new Flightdetails();
            
        }
        else if(e.getSource()== i4){
            new Reservation();
        }
        
    }
   public static void main(String[]args) {
       homepage h = new homepage();
   }

}