
package airlinemanagement;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;




public class login extends JFrame implements ActionListener  {
    JFrame f;
    JLabel l1,l2,l3,Background;
    Button b1,b2,b3;
    ImageIcon planIcon;
    TextField t1,t2;
    JPasswordField pf;
    Font f1;
    Connection con;
    
    login()
    {
        f=new JFrame("admin login");
        Background=new JLabel("",new ImageIcon("yt.jpg"),JLabel.CENTER);
        Background.setBounds(0,0,800,700);
        f.add(Background);
      
      f.setSize(700,600);
      f.setResizable(false);
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)   ; 
      f.setLocationRelativeTo(null);
      f.setLayout(null);
     
      f.setFont( new Font("Arial Black",Font.BOLD,30));
      f.setVisible(true);
      
      
      l1=new JLabel("Login Account");
      l1.setBounds(200,50,350,100);
      l1.setForeground(Color.BLACK);
      l1.setFont(new Font("Arial Black",Font.BOLD,30));
      Background.add(l1);
      
      
      
      l2=new JLabel("USERNAME");
      l2.setBounds(100,140,200,80);
       l2.setForeground(Color.BLACK);
      l2.setFont(new Font("Arial Black",Font.BOLD,20));
      Background.add(l2);
      
      
      l3=new JLabel("PASSWORD");
      l3.setBounds(100,200,200,80);
      l3.setForeground(Color.BLACK);
      l3.setFont(new Font("Arial Black",Font.BOLD,20));
      Background.add(l3);
      
      
      
      
      t1=new TextField();
      t1.setBounds(300,160,200,30);
      t1.setFont(new Font("Arial Black",Font.BOLD,20));
      Background.add(t1);
      
 pf = new JPasswordField();  
pf.setBounds(300, 220, 200, 30); 
pf.setFont(new Font("Arial Black",Font.BOLD,20));
Background.add(pf);  

      
      t2=new TextField();
      t2.setBounds(300,220,200,30);
      t2.setFont(new Font("Arial Black",Font.BOLD,20));
      Background.add(t2);
       
      b1=new Button("Sign in");
      b1.setBounds(100,300,150,40);
      b1.setBackground(Color.BLACK);
      b1.setForeground(Color.WHITE);
      
        
            b1.setFont(new Font("Arial Black",Font.BOLD,20));
            
              

            
      
      Background.add(b1);
      b1.addActionListener(this);
      
      b2=new Button("Sign up");
      b2.setBounds(350,300,150,40);
      b2.setBackground(Color.BLACK);
      b2.setForeground(Color.WHITE);
            b2.setFont(new Font("Arial Black",Font.BOLD,20));
            Background.add(b2);
      b2.addActionListener(this);
      
        b3=new Button("Cancel");
        b3.setBounds(230,400,150,40);
        b3.setBackground(Color.BLACK);
        b3.setForeground(Color.WHITE);
        b3.setFont(new Font("Arial Black",Font.BOLD,20));
        Background.add(b3);
        
      
      
    try {
        
            String url = "jdbc:mysql://localhost:3306/airlinemanagement";
            String username = "root";
            String password = "Vivo123@";

         
            Class.forName("com.mysql.cj.jdbc.Driver");

           
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airlinemanagement", "root", "Vivo123@");
        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(f, "Error connecting to the database!");
            ex.printStackTrace();
        }
    }

    public void actionPerformed(ActionEvent e) {
        
        if (e.getSource() == b1) {
    String username = t1.getText();  // Change this line
    String password = new String(pf.getPassword());

            if (validateLogin(username, password)) {
                JOptionPane.showMessageDialog(f, "Login Successful!");
               new homepage();
            } else {
                JOptionPane.showMessageDialog(f, "Invalid Username or Password");
            }
        } else if (e.getSource() == b2) {
            new userregis();
        } else if (e.getSource() == b3) {
            f.dispose();
        }
    }

    private boolean validateLogin(String username, String password) {
        try {
            String query = "SELECT * FROM user1 WHERE username=? AND password=?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, username);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();

            return rs.next(); // If a row is returned, login is successful
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(f, "Error validating login!");
            ex.printStackTrace();
            return false;
        }
    }

public static void main(String[]args){
login h =new login();
}
}
