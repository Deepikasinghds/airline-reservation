package airlinemanagement;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;




public class payement extends JFrame implements ActionListener  {
    JFrame f;
    JLabel l1,l2,l3,l4,l5,l6,l7,Background;
    Button b1,b2,b3;
    ImageIcon planIcon;
    TextField t1,t2;
    JPasswordField pf;
    Font f1;
     JTable d;
     DefaultTableModel model;
    
    payement()
    {
        f=new JFrame();
          Background=new JLabel("",new ImageIcon("p.jpg"),JLabel.CENTER);
        Background.setBounds(500,0,500,500);
        f.add(Background);
      
        
      
      f.setSize(900,700);
      f.setResizable(false);
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)   ; 
      f.setLocationRelativeTo(null);
      f.setLayout(null);
     
      f.setFont( new Font("Arial Blue",Font.BOLD,30));
      f.setVisible(true);
      
      l1=new JLabel("PAYEMENT DETAILS");
      l1.setBounds(50,30,400,100);
      l1.setForeground(Color.BLUE);
      l1.setFont( new Font("Arial Blue",Font.BOLD,30));
      
      f.add(l1);
      
      
      l2=new JLabel ("TICKET_ NO");
      l2.setBounds(50,200,300,100);
      l2.setFont( new Font("SERIF Black",Font.BOLD,30));
      f.add(l2);
      
       t1=new TextField("");
       t1.setBounds(300,230,200,40);
       t1.setFont( new Font("Arial Black",Font.BOLD,20));
       t1.setForeground(Color.WHITE);
       f.add(t1);
       
      b1=new Button("SHOW");
      b1.setBounds(350,300,150,40);
      b1.setBackground(Color.BLACK);
       b1.setForeground(Color.WHITE);
            b1.setFont(new Font("Arial Black",Font.BOLD,20));
            b1.addActionListener(this);
            f.add(b1);
      
       l2=new JLabel("");
       l2.setBounds(90,380,100,60);
       l2.setFont(new Font("Arial Black",Font.BOLD,10));
       f.add(l2);
       
       model = new DefaultTableModel();
        d = new JTable(model);
         model.setColumnIdentifiers(new String[]{"Ticket_no", "Card_no", "Card_type", "Card_holder_name", "Expiry_date","CVV_no"});
        d.setFont(new Font("Arrial Black",Font.BOLD,20));
        JScrollPane scrollPane = new JScrollPane(d);
        scrollPane.setBounds(50, 400, 600, 200);
        f.add(scrollPane);
       
      
    } 
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==b1){
             String ticketNo = t1.getText().trim(); // Get the ticket number from the text field
            model.setRowCount(0); // Clear previous data from the table
            try {
                fetchPaymentData(ticketNo); // Fetch and display payment data based on the ticket number
            } catch (SQLException ex) {
                Logger.getLogger(payement.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
            
        }
    private void fetchPaymentData(String ticketNo) throws SQLException {
        
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airlinemanagement", "root", "Vivo123@");
        
        String sql = "SELECT * FROM payement WHERE ticket_id = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, ticketNo); // Set the ticket number parameter
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {
            String cardNo = rs.getString("card_number");
            String cardType = rs.getString("card_type");
            String cardHolderName = rs.getString("card_holder_name");
            String expiryDate = rs.getString("expiry_date");
            String cvvNo = rs.getString("cvv_number");
            
            model.addRow(new Object[]{ticketNo, cardNo, cardType, cardHolderName, expiryDate, cvvNo});
        }
        // Close resources
        rs.close();
        stmt.close();
        con.close();
    }
        
    
public static void main(String [] s )
      {
          payement l=new payement();
                  }

    



}
