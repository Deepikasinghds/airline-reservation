/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airlinemanagement;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
public class userregis extends JFrame implements ActionListener {
    
   
    JFrame f;
    JLabel l1,l2,l3,l4,l5,l6,l7,t,Background,b;
    JButton b1,b2,b3;
    JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9; 
   JPanel p1;
    Connection con;
    int userId = 201;
    
    
    
    userregis(){
       
        f= new JFrame ("Home Page");
       Background=new JLabel("",new ImageIcon("t.jpg"),JLabel.CENTER);
       
        Background.setBounds(0,0,900,900);
        f.add(Background);
      
        // Color u= new Color(220,240,200);
       // f.setForeground(u);
       f.setSize(900,900);
       f.setResizable(false);
       f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       f.setLayout(null); 
                
                
l1=new JLabel("USER REGISTRATION");
l1.setBounds(5,10,380,50);
l1.setForeground(Color.BLUE);
l1.setFont( new Font("Arial Blue",Font.BOLD,30));
Background.add(l1);


      
      p1=new JPanel();
      p1.setBounds(20, 80, 800, 750);
      p1.setLayout(null);
      Color u= new Color(210,210,200);
      // p1.setForeground(u);
      //p1.setBackground(u);
      b=new JLabel("",new ImageIcon("jk.jpg"),JLabel.CENTER);
       b.setBounds(510,0,287,235);
       
       p1.add(b);
      Background.add(p1);
      
l2=new JLabel("User ID");
l2.setBounds(50,100,300,40);
l2.setFont( new Font("Arial Blue",Font.BOLD,30));
p1.add(l2);

l3=new JLabel("First Name");
l3.setBounds(50,200,300,40);
l3.setFont( new Font("Arial Blue",Font.BOLD,30));
p1.add(l3);

l4=new JLabel("Last Name");
l4.setBounds(50,300,300,40);
l4.setFont( new Font("Arial Blue",Font.BOLD,30));
p1.add(l4);


l5=new JLabel("User Name");
l5.setBounds(50,400,300,40);
l5.setFont( new Font("Arial Blue",Font.BOLD,30));
p1.add(l5);

l6=new JLabel("Password");
l6.setBounds(50,500,300,40);
l6.setFont( new Font("Arial Blue",Font.BOLD,30));
p1.add(l6);


t= new JLabel("");
t.setBounds(250,100,300,40);
t.setFont( new Font("Arial Blue",Font.BOLD,30));
t.setForeground(Color.red);
p1.add(t);

t3= new JTextField("");
t3.setBounds(250,200,300,40);
t3.setFont( new Font("Arial Blue",Font.BOLD,30));
p1.add(t3);

t4= new JTextField("");
t4.setBounds(250,300,300,40);
t4.setFont( new Font("Arial Blue",Font.BOLD,30));
p1.add(t4);

t5= new JTextField("");
t5.setBounds(250,400,300,40);
t5.setFont( new Font("Arial Blue",Font.BOLD,30));
p1.add(t5);

t6= new JTextField("");
t6.setBounds(250,500,300,40);
t6.setFont( new Font("Arial Blue",Font.BOLD,30));
p1.add(t6);




b1= new JButton("ADD");
b1.setBounds(250,600,200,40);
b1.setFont( new Font("Arial Blue",Font.BOLD,30));
b1.setBackground(Color.BLACK);
b1.setForeground(Color.WHITE);
b1.addActionListener(this);
p1.add(b1);

b2= new JButton("Sign in");
b2.setBounds(550,600,200,40);
b2.setForeground(Color.BLACK);
b2.setBackground(Color.WHITE);
b2.setFont( new Font("Arial Blue",Font.BOLD,30));
b2.addActionListener(this);
p1.add(b2);
b3= new JButton("Cancel");
b3.setBounds(400,650,200,40);
b3.setForeground(Color.BLACK);
b3.setBackground(Color.WHITE);
b3.setFont( new Font("Arial Blue",Font.BOLD,30));
b3.addActionListener(this);
p1.add(b3);



 try {
            // Replace these values with your actual database information
            String url = "jdbc:mysql://localhost:3306/airlinemanagement";
            String username = "root";
            String password = "Vivo123@";

            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airlinemanagement", "root", "Vivo123@");

        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(f, "Error connecting to the database!");
            ex.printStackTrace();
        }


userId();
f.setVisible(true);

    }  
  
    
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            JOptionPane.showMessageDialog(f, "User Successfully Registered");
            addUser();
        } else if (e.getSource() == b2) {
            new login();
            f.dispose();
        } else if (e.getSource() == b3) {
            f.dispose();
        }
    }
     private void addUser() {
    String firstName = t3.getText();
    String lastName = t4.getText();
    String userName = t5.getText();
    String password = t6.getText();
    

    try {
        
        

        
        PreparedStatement pst = con.prepareStatement("INSERT INTO user1 ( first_name, last_name, username, password) VALUES ( ?, ?, ?, ?)");
        
        pst.setString(1, firstName);
        pst.setString(2, lastName);
        pst.setString(3, userName);
        pst.setString(4, password);
        

        int rowsAffected = pst.executeUpdate();

        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(f, "User added successfully!");
            
        } else {
            JOptionPane.showMessageDialog(f, "Error adding user!");
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(f, "Error adding user!");
        ex.printStackTrace();
    }
   userId++;
        t.setText(String.valueOf(userId));
        
      }
     
     private void userId() {
    //t.setText(String.valueOf(userId));
    try {
        String query = "SELECT MAX(user_id) FROM user1";
        PreparedStatement pst = con.prepareStatement(query);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            userId = rs.getInt(1) + 1;
        } else {
            // If there are no records in the table, start with the initial value
            userId = 201;
        }
        t.setText(String.valueOf(userId));
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(f, "Error fetching user ID!");
        ex.printStackTrace();
    }

}
     
     
public static void main (String[]args){
    userregis h= new userregis();
}

    
}

    

